NOTE: This software is only for security purposes. And the developer does not take any action for the misuse of this product.
