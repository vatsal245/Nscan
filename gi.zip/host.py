#!/usr/bin/env python

#import getmac
import threading
import os
import sys
import subprocess
import socket
import nmap

port_hosts = []
host_list = []
addrn = str()
addr = str()

def _check_connection():
    global addrn
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect(('www.google.com',80))
        addrn = s.getsockname()[0]
        s.close()
        return True
    except:
        return False
        
def _get_hosts(ip):
    global host_list
    ip = addr + '0/24'
    print('please wait...')
    nm = nmap.PortScanner()
    a = nm.scan(hosts = ip, arguments = '-sP')
    for k,v in a['scan'].items():
        if str(v['status']['state']) == 'up':
            try:
                print(str(v['addresses']['ipv4']) + 'MAC==>'+ str(v['addresses']['mac']))
                host_list.append(v['addresses']['ipv4'])
            except:
                print(str(v['addresses']['ipv4']) + 'MAC ==> -')
                host_list.append(v['addresses']['ipv4'])
    print('no.of devices on the network: {}'.format(len(host_list)))
    for host in host_list:
        try:
          name = socket.gethostbyaddr(host)[0]
        except s  ocket.error:
            print('----')
            print('IP: {} \t HST NAME: {}'.format(host, name))
    print('No.of hosts connected to the network: {}'.format(len(host_list)))
    usr_input = input('1.exit\n2.port scan\n ==>')
    if usr_input == 1:
        sys.exit()
    else:
       __port_clients()

def __port_clients():
    usr_input = int(input('Enter index no: '))
    global host_list, port_hosts
    print('SCANNING PORTS PLEASE WAIT...')
    for element in host_list:
        port_hosts.append(element)
        print(port_hosts)
    for p in range(0,500):
        t = threading.Thread(target=_port_scan_, args=(port_hosts[usr_input], p))
        t.start()
def _port_scan_(client,p):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            connection = sock.connect_ex((client, p))
            if connection == 0:
                print('port {} open.'.format(p))
            sock.close()
        except:
            pass
def main():
    __banner__ = """


           _   _             _             
  _ _  ___| |_| |   ___  ___| |___  _ _ __ 
 | ' \/ -_)  _| |__/ _ \/ _ \ / / || | '_ \
 |_||_\___|\__|____\___/\___/_\_\\_,_| .__/
                                     |_|



            
"""
    print(__banner__)
    global addr, addrn
    if _check_connection():
       addr = addrn.split('.')
       addr = addr[0] + '.' + addr[1] + '.' + addr[2] + '.' 
       _get_hosts(addr)
    else:
       print('connect to a network and then try')
main()
